﻿namespace Autotitrator
{
  partial class FrmSettings
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.LblSampleVolume = new System.Windows.Forms.Label();
      this.TbxSampleVolumen = new System.Windows.Forms.TextBox();
      this.TbxMaxTitrantVol = new System.Windows.Forms.TextBox();
      this.LblMaxTitrantVol = new System.Windows.Forms.Label();
      this.TbxStabilizingTime = new System.Windows.Forms.TextBox();
      this.LblStabilizingTime = new System.Windows.Forms.Label();
      this.LblBuretComPort = new System.Windows.Forms.Label();
      this.LblBuretBaudrate = new System.Windows.Forms.Label();
      this.btnApply = new System.Windows.Forms.Button();
      this.BtnCancel = new System.Windows.Forms.Button();
      this.ChbIsSimulation = new System.Windows.Forms.CheckBox();
      this.CbxBuretBaudRate = new System.Windows.Forms.ComboBox();
      this.CbxBuretComPort = new System.Windows.Forms.ComboBox();
      this.TbxMinIncrement = new System.Windows.Forms.TextBox();
      this.LblMinIncrement = new System.Windows.Forms.Label();
      this.TbxMaxIncrement = new System.Windows.Forms.TextBox();
      this.LblMaxIncrement = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // LblSampleVolume
      // 
      this.LblSampleVolume.AutoSize = true;
      this.LblSampleVolume.Location = new System.Drawing.Point(13, 13);
      this.LblSampleVolume.Name = "LblSampleVolume";
      this.LblSampleVolume.Size = new System.Drawing.Size(100, 13);
      this.LblSampleVolume.TabIndex = 0;
      this.LblSampleVolume.Text = "Probenvolumen [ml]";
      // 
      // TbxSampleVolumen
      // 
      this.TbxSampleVolumen.Location = new System.Drawing.Point(178, 10);
      this.TbxSampleVolumen.Name = "TbxSampleVolumen";
      this.TbxSampleVolumen.Size = new System.Drawing.Size(46, 20);
      this.TbxSampleVolumen.TabIndex = 1;
      // 
      // TbxMaxTitrantVol
      // 
      this.TbxMaxTitrantVol.Location = new System.Drawing.Point(178, 36);
      this.TbxMaxTitrantVol.Name = "TbxMaxTitrantVol";
      this.TbxMaxTitrantVol.Size = new System.Drawing.Size(46, 20);
      this.TbxMaxTitrantVol.TabIndex = 3;
      // 
      // LblMaxTitrantVol
      // 
      this.LblMaxTitrantVol.AutoSize = true;
      this.LblMaxTitrantVol.Location = new System.Drawing.Point(13, 39);
      this.LblMaxTitrantVol.Name = "LblMaxTitrantVol";
      this.LblMaxTitrantVol.Size = new System.Drawing.Size(142, 13);
      this.LblMaxTitrantVol.TabIndex = 2;
      this.LblMaxTitrantVol.Text = "Max. Titriermittelvolumen [ml]";
      // 
      // TbxStabilizingTime
      // 
      this.TbxStabilizingTime.Location = new System.Drawing.Point(178, 114);
      this.TbxStabilizingTime.Name = "TbxStabilizingTime";
      this.TbxStabilizingTime.Size = new System.Drawing.Size(46, 20);
      this.TbxStabilizingTime.TabIndex = 5;
      // 
      // LblStabilizingTime
      // 
      this.LblStabilizingTime.AutoSize = true;
      this.LblStabilizingTime.Location = new System.Drawing.Point(13, 117);
      this.LblStabilizingTime.Name = "LblStabilizingTime";
      this.LblStabilizingTime.Size = new System.Drawing.Size(104, 13);
      this.LblStabilizingTime.TabIndex = 4;
      this.LblStabilizingTime.Text = "Stabilisierungszeit [s]";
      // 
      // LblBuretComPort
      // 
      this.LblBuretComPort.AutoSize = true;
      this.LblBuretComPort.Location = new System.Drawing.Point(13, 143);
      this.LblBuretComPort.Name = "LblBuretComPort";
      this.LblBuretComPort.Size = new System.Drawing.Size(128, 13);
      this.LblBuretComPort.TabIndex = 6;
      this.LblBuretComPort.Text = "COM-Schnittstelle Bürette";
      // 
      // LblBuretBaudrate
      // 
      this.LblBuretBaudrate.AutoSize = true;
      this.LblBuretBaudrate.Location = new System.Drawing.Point(13, 170);
      this.LblBuretBaudrate.Name = "LblBuretBaudrate";
      this.LblBuretBaudrate.Size = new System.Drawing.Size(125, 13);
      this.LblBuretBaudrate.TabIndex = 8;
      this.LblBuretBaudrate.Text = "Baud Rate Burette [bit/s]";
      // 
      // btnApply
      // 
      this.btnApply.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.btnApply.Location = new System.Drawing.Point(13, 226);
      this.btnApply.Name = "btnApply";
      this.btnApply.Size = new System.Drawing.Size(100, 20);
      this.btnApply.TabIndex = 10;
      this.btnApply.Text = "Übernehmen";
      this.btnApply.UseVisualStyleBackColor = true;
      this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
      // 
      // BtnCancel
      // 
      this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.BtnCancel.Location = new System.Drawing.Point(124, 226);
      this.BtnCancel.Name = "BtnCancel";
      this.BtnCancel.Size = new System.Drawing.Size(100, 20);
      this.BtnCancel.TabIndex = 11;
      this.BtnCancel.Text = "Abbrechen";
      this.BtnCancel.UseVisualStyleBackColor = true;
      this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
      // 
      // ChbIsSimulation
      // 
      this.ChbIsSimulation.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.ChbIsSimulation.Location = new System.Drawing.Point(12, 193);
      this.ChbIsSimulation.Name = "ChbIsSimulation";
      this.ChbIsSimulation.Size = new System.Drawing.Size(163, 21);
      this.ChbIsSimulation.TabIndex = 12;
      this.ChbIsSimulation.Text = "Simulationsmodus";
      this.ChbIsSimulation.UseVisualStyleBackColor = true;
      // 
      // CbxBuretBaudRate
      // 
      this.CbxBuretBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.CbxBuretBaudRate.FormattingEnabled = true;
      this.CbxBuretBaudRate.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
      this.CbxBuretBaudRate.Location = new System.Drawing.Point(161, 167);
      this.CbxBuretBaudRate.Name = "CbxBuretBaudRate";
      this.CbxBuretBaudRate.Size = new System.Drawing.Size(63, 21);
      this.CbxBuretBaudRate.TabIndex = 13;
      // 
      // CbxBuretComPort
      // 
      this.CbxBuretComPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.CbxBuretComPort.FormattingEnabled = true;
      this.CbxBuretComPort.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8"});
      this.CbxBuretComPort.Location = new System.Drawing.Point(161, 140);
      this.CbxBuretComPort.Name = "CbxBuretComPort";
      this.CbxBuretComPort.Size = new System.Drawing.Size(63, 21);
      this.CbxBuretComPort.TabIndex = 14;
      // 
      // TbxMinIncrement
      // 
      this.TbxMinIncrement.Location = new System.Drawing.Point(178, 62);
      this.TbxMinIncrement.Name = "TbxMinIncrement";
      this.TbxMinIncrement.Size = new System.Drawing.Size(46, 20);
      this.TbxMinIncrement.TabIndex = 16;
      // 
      // LblMinIncrement
      // 
      this.LblMinIncrement.AutoSize = true;
      this.LblMinIncrement.Location = new System.Drawing.Point(13, 65);
      this.LblMinIncrement.Name = "LblMinIncrement";
      this.LblMinIncrement.Size = new System.Drawing.Size(130, 13);
      this.LblMinIncrement.TabIndex = 15;
      this.LblMinIncrement.Text = "Min. Volumninkrement [ml]";
      // 
      // TbxMaxIncrement
      // 
      this.TbxMaxIncrement.Location = new System.Drawing.Point(178, 88);
      this.TbxMaxIncrement.Name = "TbxMaxIncrement";
      this.TbxMaxIncrement.Size = new System.Drawing.Size(46, 20);
      this.TbxMaxIncrement.TabIndex = 18;
      // 
      // LblMaxIncrement
      // 
      this.LblMaxIncrement.AutoSize = true;
      this.LblMaxIncrement.Location = new System.Drawing.Point(13, 91);
      this.LblMaxIncrement.Name = "LblMaxIncrement";
      this.LblMaxIncrement.Size = new System.Drawing.Size(133, 13);
      this.LblMaxIncrement.TabIndex = 17;
      this.LblMaxIncrement.Text = "Max. Volumninkrement [ml]";
      // 
      // FrmSettings
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(238, 259);
      this.Controls.Add(this.TbxMaxIncrement);
      this.Controls.Add(this.LblMaxIncrement);
      this.Controls.Add(this.TbxMinIncrement);
      this.Controls.Add(this.LblMinIncrement);
      this.Controls.Add(this.CbxBuretComPort);
      this.Controls.Add(this.CbxBuretBaudRate);
      this.Controls.Add(this.ChbIsSimulation);
      this.Controls.Add(this.BtnCancel);
      this.Controls.Add(this.btnApply);
      this.Controls.Add(this.LblBuretBaudrate);
      this.Controls.Add(this.LblBuretComPort);
      this.Controls.Add(this.TbxStabilizingTime);
      this.Controls.Add(this.LblStabilizingTime);
      this.Controls.Add(this.TbxMaxTitrantVol);
      this.Controls.Add(this.LblMaxTitrantVol);
      this.Controls.Add(this.TbxSampleVolumen);
      this.Controls.Add(this.LblSampleVolume);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Name = "FrmSettings";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Einstellungen";
      this.Load += new System.EventHandler(this.FrmSettings_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label LblSampleVolume;
    private System.Windows.Forms.TextBox TbxSampleVolumen;
    private System.Windows.Forms.TextBox TbxMaxTitrantVol;
    private System.Windows.Forms.Label LblMaxTitrantVol;
    private System.Windows.Forms.TextBox TbxStabilizingTime;
    private System.Windows.Forms.Label LblStabilizingTime;
    private System.Windows.Forms.Label LblBuretComPort;
    private System.Windows.Forms.Label LblBuretBaudrate;
    private System.Windows.Forms.Button btnApply;
    private System.Windows.Forms.Button BtnCancel;
    private System.Windows.Forms.CheckBox ChbIsSimulation;
    private System.Windows.Forms.ComboBox CbxBuretBaudRate;
    private System.Windows.Forms.ComboBox CbxBuretComPort;
    private System.Windows.Forms.TextBox TbxMinIncrement;
    private System.Windows.Forms.Label LblMinIncrement;
    private System.Windows.Forms.TextBox TbxMaxIncrement;
    private System.Windows.Forms.Label LblMaxIncrement;
  }
}