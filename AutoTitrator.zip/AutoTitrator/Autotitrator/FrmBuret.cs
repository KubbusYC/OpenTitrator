﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;
using System.Threading;
using System.Windows.Forms;
using AutoTitrator.Interfaces;

namespace Autotitrator
{
  public partial class FrmBuret : Form
  {
    private readonly ITitrationControl _titrationControl;

    public FrmBuret(ITitrationControl aTitrationControl)
    {
      _titrationControl = aTitrationControl;
      InitializeComponent();
    }

    private void BtnZeroPosition_Click(object sender, EventArgs e)
    {
      SetButtonState(false);
      _titrationControl.SetBuretZeroPosition();
      SetButtonState(true);
    }

    private void BtnStartPosition_Click(object sender, EventArgs e)
    {
      SetButtonState(false);
      _titrationControl.SetBuretStartPosition();
      SetButtonState(true);
    }

    private void SetButtonState(bool isEnabled)
    {
      BtnZeroPosition.Enabled = isEnabled;
      BtnStartPosition.Enabled = isEnabled;
      BtnStartStirrer.Enabled = isEnabled;
      BtnStopStirrer.Enabled = isEnabled;
    }

    private void BtnStartStirrer_Click(object sender, EventArgs e)
    {
      SetButtonState(false);
      _titrationControl.StartStirrer();
      SetButtonState(true);
    }

    private void BtnStopStirrer_Click(object sender, EventArgs e)
    {
      SetButtonState(false);
      _titrationControl.StopStirrer();
      SetButtonState(true);
    }
  }
}
