﻿namespace Autotitrator
{
  partial class FrmMain
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      this.PnlRight = new System.Windows.Forms.Panel();
      this.PnlValues = new System.Windows.Forms.Panel();
      this.GbxValues = new System.Windows.Forms.GroupBox();
      this.DgvValues = new System.Windows.Forms.DataGridView();
      this.PnlControl = new System.Windows.Forms.Panel();
      this.GbxControl = new System.Windows.Forms.GroupBox();
      this.BtnBuret = new System.Windows.Forms.Button();
      this.BtnResults = new System.Windows.Forms.Button();
      this.BtnSettings = new System.Windows.Forms.Button();
      this.BtnStartStop = new System.Windows.Forms.Button();
      this.PnlGraph = new System.Windows.Forms.Panel();
      this.GbxGraph = new System.Windows.Forms.GroupBox();
      this.StsMain = new System.Windows.Forms.StatusStrip();
      this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.TssActualPhValue = new System.Windows.Forms.ToolStripStatusLabel();
      this.TssActualVolume = new System.Windows.Forms.ToolStripStatusLabel();
      this.TssEndPointVolume = new System.Windows.Forms.ToolStripStatusLabel();
      this.PnlRight.SuspendLayout();
      this.PnlValues.SuspendLayout();
      this.GbxValues.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.DgvValues)).BeginInit();
      this.PnlControl.SuspendLayout();
      this.GbxControl.SuspendLayout();
      this.PnlGraph.SuspendLayout();
      this.StsMain.SuspendLayout();
      this.SuspendLayout();
      // 
      // PnlRight
      // 
      this.PnlRight.Controls.Add(this.PnlValues);
      this.PnlRight.Controls.Add(this.PnlControl);
      this.PnlRight.Dock = System.Windows.Forms.DockStyle.Right;
      this.PnlRight.Location = new System.Drawing.Point(719, 0);
      this.PnlRight.Name = "PnlRight";
      this.PnlRight.Size = new System.Drawing.Size(210, 529);
      this.PnlRight.TabIndex = 5;
      // 
      // PnlValues
      // 
      this.PnlValues.Controls.Add(this.GbxValues);
      this.PnlValues.Dock = System.Windows.Forms.DockStyle.Fill;
      this.PnlValues.Location = new System.Drawing.Point(0, 0);
      this.PnlValues.Name = "PnlValues";
      this.PnlValues.Padding = new System.Windows.Forms.Padding(5, 5, 5, 0);
      this.PnlValues.Size = new System.Drawing.Size(210, 389);
      this.PnlValues.TabIndex = 8;
      // 
      // GbxValues
      // 
      this.GbxValues.Controls.Add(this.DgvValues);
      this.GbxValues.Dock = System.Windows.Forms.DockStyle.Fill;
      this.GbxValues.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.GbxValues.Location = new System.Drawing.Point(5, 5);
      this.GbxValues.Name = "GbxValues";
      this.GbxValues.Padding = new System.Windows.Forms.Padding(5);
      this.GbxValues.Size = new System.Drawing.Size(200, 384);
      this.GbxValues.TabIndex = 0;
      this.GbxValues.TabStop = false;
      this.GbxValues.Text = "Messwerte";
      // 
      // DgvValues
      // 
      this.DgvValues.AllowUserToAddRows = false;
      this.DgvValues.AllowUserToDeleteRows = false;
      this.DgvValues.AllowUserToResizeColumns = false;
      this.DgvValues.AllowUserToResizeRows = false;
      this.DgvValues.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
      this.DgvValues.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.DgvValues.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.DgvValues.Dock = System.Windows.Forms.DockStyle.Fill;
      this.DgvValues.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
      this.DgvValues.Location = new System.Drawing.Point(5, 19);
      this.DgvValues.Name = "DgvValues";
      this.DgvValues.ReadOnly = true;
      this.DgvValues.RowHeadersVisible = false;
      this.DgvValues.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.DgvValues.ShowEditingIcon = false;
      this.DgvValues.Size = new System.Drawing.Size(190, 360);
      this.DgvValues.TabIndex = 0;
      this.DgvValues.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DgvValues_RowsAdded);
      // 
      // PnlControl
      // 
      this.PnlControl.Controls.Add(this.GbxControl);
      this.PnlControl.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.PnlControl.Location = new System.Drawing.Point(0, 389);
      this.PnlControl.Name = "PnlControl";
      this.PnlControl.Padding = new System.Windows.Forms.Padding(5, 3, 5, 5);
      this.PnlControl.Size = new System.Drawing.Size(210, 140);
      this.PnlControl.TabIndex = 7;
      // 
      // GbxControl
      // 
      this.GbxControl.Controls.Add(this.BtnBuret);
      this.GbxControl.Controls.Add(this.BtnResults);
      this.GbxControl.Controls.Add(this.BtnSettings);
      this.GbxControl.Controls.Add(this.BtnStartStop);
      this.GbxControl.Dock = System.Windows.Forms.DockStyle.Fill;
      this.GbxControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.GbxControl.Location = new System.Drawing.Point(5, 3);
      this.GbxControl.Name = "GbxControl";
      this.GbxControl.Size = new System.Drawing.Size(200, 132);
      this.GbxControl.TabIndex = 1;
      this.GbxControl.TabStop = false;
      this.GbxControl.Text = "Steuerung";
      // 
      // BtnBuret
      // 
      this.BtnBuret.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.BtnBuret.Location = new System.Drawing.Point(101, 19);
      this.BtnBuret.Name = "BtnBuret";
      this.BtnBuret.Size = new System.Drawing.Size(96, 36);
      this.BtnBuret.TabIndex = 4;
      this.BtnBuret.Text = "Bürette";
      this.BtnBuret.UseVisualStyleBackColor = true;
      this.BtnBuret.Click += new System.EventHandler(this.BtnBuret_Click);
      // 
      // BtnResults
      // 
      this.BtnResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.BtnResults.Location = new System.Drawing.Point(3, 19);
      this.BtnResults.Name = "BtnResults";
      this.BtnResults.Size = new System.Drawing.Size(96, 36);
      this.BtnResults.TabIndex = 3;
      this.BtnResults.Text = "Resultate";
      this.BtnResults.UseVisualStyleBackColor = true;
      this.BtnResults.Click += new System.EventHandler(this.BtnResults_Click);
      // 
      // BtnSettings
      // 
      this.BtnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.BtnSettings.Location = new System.Drawing.Point(3, 56);
      this.BtnSettings.Name = "BtnSettings";
      this.BtnSettings.Size = new System.Drawing.Size(194, 36);
      this.BtnSettings.TabIndex = 2;
      this.BtnSettings.Text = "Einstellungen";
      this.BtnSettings.UseVisualStyleBackColor = true;
      this.BtnSettings.Click += new System.EventHandler(this.BtnSettings_Click);
      // 
      // BtnStartStop
      // 
      this.BtnStartStop.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.BtnStartStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.BtnStartStop.Location = new System.Drawing.Point(3, 93);
      this.BtnStartStop.Name = "BtnStartStop";
      this.BtnStartStop.Size = new System.Drawing.Size(194, 36);
      this.BtnStartStop.TabIndex = 0;
      this.BtnStartStop.UseVisualStyleBackColor = true;
      this.BtnStartStop.Click += new System.EventHandler(this.BtnStartStop_Click);
      // 
      // PnlGraph
      // 
      this.PnlGraph.Controls.Add(this.GbxGraph);
      this.PnlGraph.Dock = System.Windows.Forms.DockStyle.Fill;
      this.PnlGraph.Location = new System.Drawing.Point(0, 0);
      this.PnlGraph.Name = "PnlGraph";
      this.PnlGraph.Padding = new System.Windows.Forms.Padding(5, 5, 0, 5);
      this.PnlGraph.Size = new System.Drawing.Size(719, 529);
      this.PnlGraph.TabIndex = 6;
      // 
      // GbxGraph
      // 
      this.GbxGraph.Dock = System.Windows.Forms.DockStyle.Fill;
      this.GbxGraph.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.GbxGraph.Location = new System.Drawing.Point(5, 5);
      this.GbxGraph.Name = "GbxGraph";
      this.GbxGraph.Size = new System.Drawing.Size(714, 519);
      this.GbxGraph.TabIndex = 1;
      this.GbxGraph.TabStop = false;
      this.GbxGraph.Text = "Titrationskurve";
      // 
      // StsMain
      // 
      this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.TssActualPhValue,
            this.TssActualVolume,
            this.TssEndPointVolume});
      this.StsMain.Location = new System.Drawing.Point(0, 529);
      this.StsMain.Name = "StsMain";
      this.StsMain.Size = new System.Drawing.Size(929, 22);
      this.StsMain.TabIndex = 3;
      this.StsMain.Text = "statusStrip1";
      // 
      // toolStripStatusLabel1
      // 
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
      // 
      // TssActualPhValue
      // 
      this.TssActualPhValue.AutoSize = false;
      this.TssActualPhValue.Name = "TssActualPhValue";
      this.TssActualPhValue.Size = new System.Drawing.Size(140, 17);
      this.TssActualPhValue.Text = "Aktueller pH-Wert: ";
      this.TssActualPhValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // TssActualVolume
      // 
      this.TssActualVolume.AutoSize = false;
      this.TssActualVolume.Name = "TssActualVolume";
      this.TssActualVolume.Size = new System.Drawing.Size(180, 17);
      this.TssActualVolume.Text = "Titriermittel-Verbrauch: ";
      this.TssActualVolume.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // TssEndPointVolume
      // 
      this.TssEndPointVolume.AutoSize = false;
      this.TssEndPointVolume.Name = "TssEndPointVolume";
      this.TssEndPointVolume.Size = new System.Drawing.Size(160, 17);
      this.TssEndPointVolume.Text = "Äquivalenzvolumen: ";
      this.TssEndPointVolume.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // FrmMain
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(929, 551);
      this.Controls.Add(this.PnlGraph);
      this.Controls.Add(this.PnlRight);
      this.Controls.Add(this.StsMain);
      this.Name = "FrmMain";
      this.Text = "Autotitrator";
      this.Load += new System.EventHandler(this.FrmMain_Load);
      this.PnlRight.ResumeLayout(false);
      this.PnlValues.ResumeLayout(false);
      this.GbxValues.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.DgvValues)).EndInit();
      this.PnlControl.ResumeLayout(false);
      this.GbxControl.ResumeLayout(false);
      this.PnlGraph.ResumeLayout(false);
      this.StsMain.ResumeLayout(false);
      this.StsMain.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Panel PnlRight;
    private System.Windows.Forms.Panel PnlValues;
    private System.Windows.Forms.GroupBox GbxValues;
    private System.Windows.Forms.DataGridView DgvValues;
    private System.Windows.Forms.Panel PnlControl;
    private System.Windows.Forms.GroupBox GbxControl;
    private System.Windows.Forms.Panel PnlGraph;
    private System.Windows.Forms.GroupBox GbxGraph;
    private System.Windows.Forms.Button BtnSettings;
    private System.Windows.Forms.Button BtnStartStop;
    private System.Windows.Forms.Button BtnResults;
    private System.Windows.Forms.Button BtnBuret;
    private System.Windows.Forms.StatusStrip StsMain;
    private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    private System.Windows.Forms.ToolStripStatusLabel TssActualPhValue;
    private System.Windows.Forms.ToolStripStatusLabel TssActualVolume;
    private System.Windows.Forms.ToolStripStatusLabel TssEndPointVolume;

  }
}

