﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System.Windows.Forms;

namespace Autotitrator
{
  public partial class FrmResults : Form
  {
    private readonly double _titrantAmount;
    private readonly double _sampleVolume;

    public FrmResults(double aTitrantAmount, double aSampleVolume)
    {
      _titrantAmount = aTitrantAmount;
      _sampleVolume = aSampleVolume;
      InitializeComponent();
    }

    private void BtnCalculate_Click(object sender, System.EventArgs e)
    {
      double titrantConcentration;
      if (double.TryParse(TbxTitrantConc.Text, out titrantConcentration))
      {
        TbxResult.Text = (_titrantAmount*titrantConcentration/_sampleVolume).ToString("F6");
      }
      else
      {
        MessageBox.Show(@"Geben Sie eine gültige Titriermittel-Konzentration ein.");
      }
    }

    private void FrmResults_Load(object sender, System.EventArgs e)
    {
      TbxTitrantAmount.Text = _titrantAmount.ToString("F2");
    }

    private void TbxTitrantConc_TextChanged(object sender, System.EventArgs e)
    {
      TbxResult.Text = string.Empty;
    }
  }
}
