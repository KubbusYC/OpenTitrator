﻿namespace Autotitrator
{
  partial class FrmResults
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.LblConcentration = new System.Windows.Forms.Label();
      this.TbxTitrantConc = new System.Windows.Forms.TextBox();
      this.LblTitrantConcUnit = new System.Windows.Forms.Label();
      this.LblSampleConcUnit = new System.Windows.Forms.Label();
      this.TbxResult = new System.Windows.Forms.TextBox();
      this.LblResult = new System.Windows.Forms.Label();
      this.BtnCalculate = new System.Windows.Forms.Button();
      this.LblTitrantAmountUnit = new System.Windows.Forms.Label();
      this.TbxTitrantAmount = new System.Windows.Forms.TextBox();
      this.LblTitrantAmount = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // LblConcentration
      // 
      this.LblConcentration.AutoSize = true;
      this.LblConcentration.Location = new System.Drawing.Point(12, 20);
      this.LblConcentration.Name = "LblConcentration";
      this.LblConcentration.Size = new System.Drawing.Size(127, 13);
      this.LblConcentration.TabIndex = 0;
      this.LblConcentration.Text = "Konzentration Tiitriermittel";
      // 
      // TbxTitrantConc
      // 
      this.TbxTitrantConc.Location = new System.Drawing.Point(144, 17);
      this.TbxTitrantConc.Name = "TbxTitrantConc";
      this.TbxTitrantConc.Size = new System.Drawing.Size(57, 20);
      this.TbxTitrantConc.TabIndex = 1;
      this.TbxTitrantConc.TextChanged += new System.EventHandler(this.TbxTitrantConc_TextChanged);
      // 
      // LblTitrantConcUnit
      // 
      this.LblTitrantConcUnit.AutoSize = true;
      this.LblTitrantConcUnit.Location = new System.Drawing.Point(207, 20);
      this.LblTitrantConcUnit.Name = "LblTitrantConcUnit";
      this.LblTitrantConcUnit.Size = new System.Drawing.Size(30, 13);
      this.LblTitrantConcUnit.TabIndex = 2;
      this.LblTitrantConcUnit.Text = "mol/l";
      // 
      // LblSampleConcUnit
      // 
      this.LblSampleConcUnit.AutoSize = true;
      this.LblSampleConcUnit.Location = new System.Drawing.Point(207, 74);
      this.LblSampleConcUnit.Name = "LblSampleConcUnit";
      this.LblSampleConcUnit.Size = new System.Drawing.Size(30, 13);
      this.LblSampleConcUnit.TabIndex = 5;
      this.LblSampleConcUnit.Text = "mol/l";
      // 
      // TbxResult
      // 
      this.TbxResult.Location = new System.Drawing.Point(144, 71);
      this.TbxResult.Name = "TbxResult";
      this.TbxResult.ReadOnly = true;
      this.TbxResult.Size = new System.Drawing.Size(57, 20);
      this.TbxResult.TabIndex = 4;
      // 
      // LblResult
      // 
      this.LblResult.AutoSize = true;
      this.LblResult.Location = new System.Drawing.Point(12, 74);
      this.LblResult.Name = "LblResult";
      this.LblResult.Size = new System.Drawing.Size(103, 13);
      this.LblResult.TabIndex = 3;
      this.LblResult.Text = "Konzentration Probe";
      // 
      // BtnCalculate
      // 
      this.BtnCalculate.Location = new System.Drawing.Point(143, 109);
      this.BtnCalculate.Name = "BtnCalculate";
      this.BtnCalculate.Size = new System.Drawing.Size(94, 23);
      this.BtnCalculate.TabIndex = 6;
      this.BtnCalculate.Text = "Berechnen";
      this.BtnCalculate.UseVisualStyleBackColor = true;
      this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
      // 
      // LblTitrantAmountUnit
      // 
      this.LblTitrantAmountUnit.AutoSize = true;
      this.LblTitrantAmountUnit.Location = new System.Drawing.Point(207, 47);
      this.LblTitrantAmountUnit.Name = "LblTitrantAmountUnit";
      this.LblTitrantAmountUnit.Size = new System.Drawing.Size(17, 13);
      this.LblTitrantAmountUnit.TabIndex = 9;
      this.LblTitrantAmountUnit.Text = "ml";
      // 
      // TbxTitrantAmount
      // 
      this.TbxTitrantAmount.Location = new System.Drawing.Point(144, 44);
      this.TbxTitrantAmount.Name = "TbxTitrantAmount";
      this.TbxTitrantAmount.ReadOnly = true;
      this.TbxTitrantAmount.Size = new System.Drawing.Size(57, 20);
      this.TbxTitrantAmount.TabIndex = 8;
      // 
      // LblTitrantAmount
      // 
      this.LblTitrantAmount.AutoSize = true;
      this.LblTitrantAmount.Location = new System.Drawing.Point(12, 47);
      this.LblTitrantAmount.Name = "LblTitrantAmount";
      this.LblTitrantAmount.Size = new System.Drawing.Size(109, 13);
      this.LblTitrantAmount.TabIndex = 7;
      this.LblTitrantAmount.Text = "Verbrauch Titriermittel";
      // 
      // FrmResults
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(249, 144);
      this.Controls.Add(this.LblTitrantAmountUnit);
      this.Controls.Add(this.TbxTitrantAmount);
      this.Controls.Add(this.LblTitrantAmount);
      this.Controls.Add(this.BtnCalculate);
      this.Controls.Add(this.LblSampleConcUnit);
      this.Controls.Add(this.TbxResult);
      this.Controls.Add(this.LblResult);
      this.Controls.Add(this.LblTitrantConcUnit);
      this.Controls.Add(this.TbxTitrantConc);
      this.Controls.Add(this.LblConcentration);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "FrmResults";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Resultat berechnen";
      this.Load += new System.EventHandler(this.FrmResults_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label LblConcentration;
    private System.Windows.Forms.TextBox TbxTitrantConc;
    private System.Windows.Forms.Label LblTitrantConcUnit;
    private System.Windows.Forms.Label LblSampleConcUnit;
    private System.Windows.Forms.TextBox TbxResult;
    private System.Windows.Forms.Label LblResult;
    private System.Windows.Forms.Button BtnCalculate;
    private System.Windows.Forms.Label LblTitrantAmountUnit;
    private System.Windows.Forms.TextBox TbxTitrantAmount;
    private System.Windows.Forms.Label LblTitrantAmount;
  }
}