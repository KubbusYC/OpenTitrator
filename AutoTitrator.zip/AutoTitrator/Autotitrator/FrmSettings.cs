﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AutoTitrator;

namespace Autotitrator
{
  public partial class FrmSettings : Form
  {
    private readonly TitratorSettings _settings;

    public FrmSettings(TitratorSettings aSettings)
    {
      InitializeComponent();
      _settings = aSettings;
    }

    private void btnApply_Click(object sender, EventArgs e)
    {
      try
      {
        _settings.SampleVolume = VatidateField(LblSampleVolume, TbxSampleVolumen.Text, 20.0, 50.0);
        _settings.MaxTitrantVolume = VatidateField(LblMaxTitrantVol, TbxMaxTitrantVol.Text, 2.0, 9.0);
        _settings.MinVolumeIncrement = VatidateField(LblMinIncrement, TbxMinIncrement.Text, 0.01, 0.10);
        _settings.MaxVolumeIncrement = VatidateField(LblMaxIncrement, TbxMaxIncrement.Text, 0.10, 0.50);
        _settings.StabilizingTimeSec = VatidateField(LblStabilizingTime, TbxStabilizingTime.Text, 1, 20);
        _settings.BuretBaudRate = VatidateField(LblBuretBaudrate, CbxBuretBaudRate.Text, 9600, 115200);
        _settings.BuretComPort = VatidateField(LblSampleVolume, CbxBuretComPort.Text);
        _settings.IsSimulation = ChbIsSimulation.Checked;

        Close();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
        DialogResult = DialogResult.None;
      }
    }

    private void BtnCancel_Click(object sender, EventArgs e)
    {
      Close();
    }

    private double VatidateField(Label aLabel, string aValue, double aMinimum, double aMaximum)
    {
      double result;
      if (double.TryParse(aValue, out result))
      {
        if (result < aMinimum)
        {
          throw new Exception(@"Der Wert im Feld '" + aLabel.Text + @"' liegt unter dem Minimalwert (" + aMinimum.ToString("F1") + @")");
        }

        if (result > aMaximum)
        {
          throw new Exception(@"Der Wert im Feld '" + aLabel.Text + @"' liegt über dem Maximalwert (" + aMaximum.ToString("F1") + @")");
        }

        return result;
      }

      throw new Exception(@"Das Feld '" + aLabel.Text + @"' enthält einen ungültigen Wert");
    }

    private int VatidateField(Label aLabel, string aValue, int aMinimum, int aMaximum)
    {
      int result;
      if (int.TryParse(aValue, out result))
      {
        if (result < aMinimum)
        {
          throw new Exception(@"Der Wert im Feld '" + aLabel.Text + @"' liegt unter dem Minimalwert (" + aMinimum + @")");
        }
        
        if (result > aMaximum)
        {
          throw new Exception(@"Der Wert im Feld '" + aLabel.Text + @"' liegt über dem Maximalwert (" + aMaximum + @")");
        }

        return result;
      }

      throw new Exception(@"Das Feld '" + aLabel.Text + @"' enthält einen ungültigen Wert");
    }

    private string VatidateField(Label aLabel, string aValue)
    {
      if (!string.IsNullOrEmpty(aValue))
      {
        return aValue;
      }

      throw new Exception(@"Das Feld '" + aLabel.Text + @"' enthält einen ungültigen Wert");
    }

    private void FrmSettings_Load(object sender, EventArgs e)
    {
      if (_settings != null)
      {
        TbxSampleVolumen.Text = _settings.SampleVolume.ToString("F1");
        TbxMaxTitrantVol.Text = _settings.MaxTitrantVolume.ToString("F1");
        TbxMinIncrement.Text = _settings.MinVolumeIncrement.ToString("F2");
        TbxMaxIncrement.Text = _settings.MaxVolumeIncrement.ToString("F2");
        TbxStabilizingTime.Text = _settings.StabilizingTimeSec.ToString();
        CbxBuretComPort.Text = _settings.BuretComPort;
        CbxBuretBaudRate.Text = _settings.BuretBaudRate.ToString();
        ChbIsSimulation.Checked = _settings.IsSimulation;
      }
    }
  }
}
