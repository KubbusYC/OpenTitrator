﻿namespace Autotitrator
{
  partial class FrmBuret
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.BtnZeroPosition = new System.Windows.Forms.Button();
      this.BtnStartPosition = new System.Windows.Forms.Button();
      this.BtnStartStirrer = new System.Windows.Forms.Button();
      this.BtnStopStirrer = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // BtnZeroPosition
      // 
      this.BtnZeroPosition.Location = new System.Drawing.Point(13, 13);
      this.BtnZeroPosition.Name = "BtnZeroPosition";
      this.BtnZeroPosition.Size = new System.Drawing.Size(149, 23);
      this.BtnZeroPosition.TabIndex = 0;
      this.BtnZeroPosition.Text = "Nullposition anfahren";
      this.BtnZeroPosition.UseVisualStyleBackColor = true;
      this.BtnZeroPosition.Click += new System.EventHandler(this.BtnZeroPosition_Click);
      // 
      // BtnStartPosition
      // 
      this.BtnStartPosition.Location = new System.Drawing.Point(13, 42);
      this.BtnStartPosition.Name = "BtnStartPosition";
      this.BtnStartPosition.Size = new System.Drawing.Size(149, 23);
      this.BtnStartPosition.TabIndex = 1;
      this.BtnStartPosition.Text = "Startposition anfahren";
      this.BtnStartPosition.UseVisualStyleBackColor = true;
      this.BtnStartPosition.Click += new System.EventHandler(this.BtnStartPosition_Click);
      // 
      // BtnStartStirrer
      // 
      this.BtnStartStirrer.Location = new System.Drawing.Point(13, 72);
      this.BtnStartStirrer.Name = "BtnStartStirrer";
      this.BtnStartStirrer.Size = new System.Drawing.Size(149, 23);
      this.BtnStartStirrer.TabIndex = 2;
      this.BtnStartStirrer.Text = "Rührer starten";
      this.BtnStartStirrer.UseVisualStyleBackColor = true;
      this.BtnStartStirrer.Click += new System.EventHandler(this.BtnStartStirrer_Click);
      // 
      // BtnStopStirrer
      // 
      this.BtnStopStirrer.Location = new System.Drawing.Point(13, 102);
      this.BtnStopStirrer.Name = "BtnStopStirrer";
      this.BtnStopStirrer.Size = new System.Drawing.Size(149, 23);
      this.BtnStopStirrer.TabIndex = 3;
      this.BtnStopStirrer.Text = "Rührer stoppen";
      this.BtnStopStirrer.UseVisualStyleBackColor = true;
      this.BtnStopStirrer.Click += new System.EventHandler(this.BtnStopStirrer_Click);
      // 
      // FrmBuret
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(175, 138);
      this.Controls.Add(this.BtnStopStirrer);
      this.Controls.Add(this.BtnStartStirrer);
      this.Controls.Add(this.BtnStartPosition);
      this.Controls.Add(this.BtnZeroPosition);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "FrmBuret";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Bürette bedienen";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button BtnZeroPosition;
    private System.Windows.Forms.Button BtnStartPosition;
    private System.Windows.Forms.Button BtnStartStirrer;
    private System.Windows.Forms.Button BtnStopStirrer;
  }
}