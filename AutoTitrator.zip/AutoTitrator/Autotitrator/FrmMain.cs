﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using AutoTitrator;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using OxyPlot.WindowsForms;

namespace Autotitrator
{
  public partial class FrmMain : Form
  {
    private const string SettingsFileName = "TitratorSettings";
    private TitratorSettings _titratorSettings;
    private TitrationControl _titrationControl;
    private DataTable _measuredValues;
    private PlotView _plot;
    private PlotModel _plotModel;
    private LineSeries _lineSeriesA;
    private LineSeries _lineSeriesB;
    private double _titrantAmount;
    private bool _titrationActive;

    public FrmMain()
    {
      InitializeComponent();
      SetUpDataTable();
      SetupDataView();
      SetupGraph();
    }

    public void SetupControl()
    {
      _titrationControl = new TitrationControl(_titratorSettings)
      {
        NewDataPoint = StoreDataPoint,
        NewMeasuredValue = DisplayValues,
        TitrationComplete = TitrationComplete
      };

      _titrationControl.InitializeHardware();
    }

    private void SetUpDataTable()
    {
      _measuredValues = new DataTable();
      _measuredValues.Columns.Add("V [mL]  ");
      _measuredValues.Columns.Add("pH Wert");
      _measuredValues.Columns.Add("dpH/dV");
    }

    private void SetupDataView()
    {
      DgvValues.DataSource = _measuredValues;
      DgvValues.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
      DgvValues.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
      DgvValues.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

      foreach (DataGridViewColumn col in DgvValues.Columns)
      {
        col.SortMode = DataGridViewColumnSortMode.NotSortable;
      }
    }

    private void SetupGraph()
    {
      var volumeAxis = new LinearAxis { Position = AxisPosition.Bottom, Title = "Volumen [ml]", Minimum = -0.15, Maximum = 10.15, IsPanEnabled = false, IsZoomEnabled = false};
      var primaryAxis = new LinearAxis { Position = AxisPosition.Left, Key = "Value", Title = "pH Wert", Maximum = 14.0, IsPanEnabled = false, IsZoomEnabled = false};
      var secondaryAxis = new LinearAxis { Position = AxisPosition.Right, Key = "Slope", Title = "Steigung (dpH/dV)", Maximum = 300, IsPanEnabled = false, IsZoomEnabled = false};

      _lineSeriesA = new LineSeries {YAxisKey = "Value"};
      _lineSeriesB = new LineSeries {YAxisKey = "Slope"};
      _lineSeriesA.MarkerType = MarkerType.Triangle;
      _lineSeriesB.LineStyle = LineStyle.DashDot;
      _lineSeriesB.StrokeThickness = 1;

      SuspendLayout();
      _plotModel = new PlotModel { Title = "" };
      _plotModel.Axes.Add(volumeAxis);
      _plotModel.Axes.Add(primaryAxis);
      _plotModel.Axes.Add(secondaryAxis);
      _plotModel.Series.Add(_lineSeriesA);
      _plotModel.Series.Add(_lineSeriesB);
      _plot = new PlotView
      {
        Model = _plotModel,
        Dock = DockStyle.Fill,
        BackColor = Color.Snow
      };
      GbxGraph.Controls.Add(_plot);
      ResumeLayout(false);
    }

    private void BtnStartStop_Click(object sender, EventArgs e)
    {
      if (!_titrationActive)
      {
        _measuredValues.Clear();
        _lineSeriesA.Points.Clear();
        _lineSeriesB.Points.Clear();
        _plotModel.InvalidatePlot(true);
        _titrationControl.StartTitration();
        SetStartButtonState(true);
      }
      else
      {
        _titrationControl.StopTitration();
      }
    }

    private void DgvValues_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
    {
      var dataRow = _measuredValues.Rows[e.RowIndex];
      _lineSeriesA.Points.Add(new DataPoint(Convert.ToDouble(dataRow.ItemArray[0]), Convert.ToDouble(dataRow.ItemArray[1])));

      if (e.RowIndex > 0)
      {
        var meanVolume = (Convert.ToDouble(_measuredValues.Rows[e.RowIndex-1].ItemArray[0]) + Convert.ToDouble(dataRow.ItemArray[0])) / 2;
        _lineSeriesB.Points.Add(new DataPoint(meanVolume, Convert.ToDouble(dataRow.ItemArray[2])));
      }

      _plotModel.InvalidatePlot(true);
    }

    private void StoreDataPoint(double aVolume, double aValue, double aSlope)
    {
      if (InvokeRequired)
      {
        Invoke(new MethodInvoker(() => {_measuredValues.Rows.Add(aVolume.ToString("F3"), aValue.ToString("F3"), aSlope.ToString("F3"));}));
      }
      else
      {
        _measuredValues.Rows.Add(aVolume.ToString("F3"), aValue.ToString("F3"), aSlope.ToString("F3"));
      }
    }

    private void TitrationComplete()
    {
      var maxSlope = 0.0;
      var maxIndex = 0;

      for (int rowIndex = 0; rowIndex < _measuredValues.Rows.Count; rowIndex++)
      {
        var actSlope = Convert.ToDouble(_measuredValues.Rows[rowIndex].ItemArray[2]);
        
        if (actSlope > maxSlope)
        {
          maxSlope = actSlope;
          maxIndex = rowIndex;
        }
      }

      if (maxIndex > 0)
      {
        _titrantAmount = (Convert.ToDouble(_measuredValues.Rows[maxIndex - 1].ItemArray[0]) + 
                         Convert.ToDouble(_measuredValues.Rows[maxIndex].ItemArray[0])) / 2;
      }
      else
      {
        _titrantAmount = 0;
      }

      if (InvokeRequired)
      {
        Invoke(new MethodInvoker(() =>
        {
          SetStartButtonState(false);
          TssEndPointVolume.Text = @"Äquivalenzvolumen: " + _titrantAmount.ToString("F2") + @" ml";
        }));
      }
      else
      {
        SetStartButtonState(false);
        TssEndPointVolume.Text = @"Äquivalenzvolumen: " + _titrantAmount.ToString("F2") + @" ml";
      }
    }

    private void DisplayValues (double aVolume, double aPhValue)
    {
      if (InvokeRequired)
      {
        Invoke(new MethodInvoker(() =>
        {
          TssActualPhValue.Text = @"Aktueller pH-Wert: " + aPhValue.ToString("F2");
          TssActualVolume.Text = @"Titriermittel-Verbrauch: " + aVolume.ToString("F2") + @" ml";
        }));
      }
      else
      {
        TssActualPhValue.Text = aPhValue.ToString("F2");
      }
    }

    private void BtnSettings_Click(object sender, EventArgs e)
    {
      var frmSettings = new FrmSettings(_titratorSettings);
      if (frmSettings.ShowDialog() == DialogResult.OK)
      {
        ObjectToXmlFileSerializer.SerializeToXmlFile(_titratorSettings, SettingsFileName);
      }
    }

    private void BtnBuret_Click(object sender, EventArgs e)
    {
      var frmBuret = new FrmBuret(_titrationControl);
      frmBuret.ShowDialog();
    }

    private void FrmMain_Load(object sender, EventArgs e)
    {
      _titratorSettings = ObjectToXmlFileSerializer.CreateFromXmlFile<TitratorSettings>(SettingsFileName);

      if (_titratorSettings == null)
      {
        MessageBox.Show(@"Titrator-Einstellungen nicht gefunden");
        Close();
      }

      SetStartButtonState(false);
      SetupControl();
    }

    private void BtnResults_Click(object sender, EventArgs e)
    {
      FrmResults frmResults = new FrmResults(_titrantAmount, _titratorSettings.SampleVolume);
      frmResults.ShowDialog();
    }

    private void SetStartButtonState(bool isActive)
    {
      _titrationActive = isActive;
      BtnStartStop.Text = isActive ? @"Titration stoppen" : @"Titration starten" ;
      BtnSettings.Enabled = !isActive;
      BtnBuret.Enabled = !isActive;
      BtnResults.Enabled = !isActive;
    }
  }
}
