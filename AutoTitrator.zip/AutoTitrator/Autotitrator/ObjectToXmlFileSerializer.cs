﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, Nikita Freiermuth
//-------------------------------------------------------------------------------------------------

using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace Autotitrator
{
  public class ObjectToXmlFileSerializer
  {
    public static T CreateFromXmlFile<T>(string aFilePath)
    {
      var serializer = new XmlSerializer(typeof(T));

      using (var reader = new StreamReader(aFilePath))
      {
        var instance = (T)serializer.Deserialize(reader);
        reader.Close();
        return instance;
      }
    }

    public static void SerializeToXmlFile(object aInstance, string aFilePath)
    {
      var serializer = new XmlSerializer(aInstance.GetType());

      using (var writer = new StreamWriter(aFilePath, false, Encoding.UTF8))
      {
        serializer.Serialize(writer, aInstance);
        writer.Close();
      }
    }
  }
}
