﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTitrator.DaqDevice
{
  public interface IDaqDevice
  {
    void InitializeDaqDevice();
    void FinalizeDaqDevice();
    double GetTemperature();
    double ReadPhValue();
  }
}
