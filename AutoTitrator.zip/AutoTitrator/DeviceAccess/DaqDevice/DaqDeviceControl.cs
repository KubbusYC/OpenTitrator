﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;
using System.Text;


namespace AutoTitrator.DaqDevice
{
  /// <summary> High level control  the Pico DrDaq device. </summary>
  public class DaqDeviceControl : IDaqDevice
  {
    private const int MaxInfoLength = 200;
    private const short EnableRgb = 1;
    private bool _isInitialized;
    private bool _rgbIsEnabled;
    private short _devicehandle;

    public string SerialNumber { get; private set; }
    public string DriverVersion { get; private set; }
    public string UsbVersion { get; private set; }
    public string HardwareVersion { get; private set; }
    public string VariantInfo { get; private set; }
    public string CalibrationDate { get; private set; }
    public string KernelDriverVersion { get; private set; }

    public DaqDeviceControl()
    {
      _devicehandle = 0;
      _isInitialized = false;
      _rgbIsEnabled = false;
    }

    public void InitializeDaqDevice()
    {
      var status = DaqDeviceDriver.OpenUnit(out _devicehandle);
      _isInitialized = status == 0;

      if (_isInitialized)
      {
        DriverVersion = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.DriverVersion);
        UsbVersion = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.UsbVersion);
        HardwareVersion = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.HardwareVersion);
        VariantInfo = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.VariantInfo);
        SerialNumber = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.BatchAndSerial);
        CalibrationDate = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.CalibrationDate);
        KernelDriverVersion = GetDeviceInfoString(DaqDeviceDriver.DaqInfoType.KernelDriverVersion);
      }
      else
      {
        throw new DaqDeviceException("Opening DAQ device failed (Status: " + status + ")", DateTime.Now);
      }
    }

    public void FinalizeDaqDevice()
    {
      var status = DaqDeviceDriver.CloseUnit(_devicehandle);

      if (status != 0)
      {
        throw new DaqDeviceException("Closing DAQ device failed (Status: " + status + ")");
      }
    }

    public void SetRgbLedColor(ushort aRedPart, ushort aGreenPart, ushort aBluePart)
    {
      SetRgbMode(true);

      var status = DaqDeviceDriver.SetRGBLED(_devicehandle, aRedPart, aGreenPart, aBluePart);

      if (status != 0)
      {
        throw new DaqDeviceException("Setting RGB Led color failed (Status: " + status + ")");
      }
    }

    public double ReadPhValue()
    {
      bool isOverflow;
      var adcValue = GetChannelAdcValue(DaqDeviceDriver.DaqInput.PhSensor, out isOverflow);
      return Convert.ToDouble(adcValue / 100.0);
    }

    public double GetTemperature()
    {
      bool isOverflow;
      var adcValue = GetChannelAdcValue(DaqDeviceDriver.DaqInput.Temperature, out isOverflow);
      return Convert.ToDouble(adcValue/10.0);
    }

    public double GetExternalSensorOne()
    {
      bool isOverflow;
      var adcValue = GetChannelAdcValue(DaqDeviceDriver.DaqInput.SensorOne, out isOverflow);
      return Convert.ToDouble(adcValue / 10.0);
    }

    private string GetDeviceInfoString(DaqDeviceDriver.DaqInfoType aInfoType)
    {
      short requiredSize;
      var infoString = new StringBuilder(MaxInfoLength);
      var status = DaqDeviceDriver.GetUnitInfo(_devicehandle, infoString, MaxInfoLength, out requiredSize, aInfoType);

      if (status == 0)
      {
        if (requiredSize > MaxInfoLength)
        {
          throw new DaqDeviceException("Insufficient device info string length (Required length: " + requiredSize + ", Actual length: " + MaxInfoLength);
        }

        return infoString.ToString();
      }
        
      throw new DaqDeviceException("Retrieving device info string failed (Info type: " + aInfoType + ", Status: " + status);
    }

    private short GetChannelAdcValue(DaqDeviceDriver.DaqInput aDaqInput, out bool isOverflow)
    {
      ushort overflow;
      short adcValue;

      var status = DaqDeviceDriver.GetSingle(_devicehandle, aDaqInput, out adcValue, out overflow);

      if (status != 0)
      {
        throw new DaqDeviceException("Reading channel ADC value failed (Status: " + status + ")");
      }

      isOverflow = Convert.ToBoolean(overflow);
      return adcValue;
    }

    private void SetRgbMode(bool isEnabled)
    {
      if (!_rgbIsEnabled)
      {
        var status = DaqDeviceDriver.EnableRGBLED(_devicehandle, Convert.ToInt16(isEnabled));

        if (status != 0)
        {
          throw new DaqDeviceException("Closing DAQ device failed (Status: " + status + ")");
        }

        _rgbIsEnabled = isEnabled;
      }
    }
  }
}