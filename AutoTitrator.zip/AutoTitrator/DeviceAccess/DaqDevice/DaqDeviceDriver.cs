﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System.Runtime.InteropServices;
using System.Text;

namespace AutoTitrator.DaqDevice
{
  /// <summary> Controls the access to the Pico DrDaq device. </summary>
  public class DaqDeviceDriver
  {
    private const string DriverDllName = "USBDrDAQ.dll";

    /// <summary> Available DAQ input channels </summary>
    public enum DaqInput
    {
      /// <summary> Undefined channel </summary>
      Undefined,
      /// <summary> Ext. sensor 1 </summary>
      SensorOne,
      /// <summary> Ext. sensor 2 </summary>
      SensorTwo,
      /// <summary> Ext. sensor 3 </summary>
      SensorThree,
      /// <summary> Oscilloscope </summary>
      ScopeInput,
      /// <summary> pH electrode</summary>
      PhSensor,
      /// <summary> Resistance input </summary>
      Resistance,
      /// <summary> Light sensor </summary>
      LightSensor,
      /// <summary> Thermistor input </summary>
      Temperature,
      /// <summary> Microphone waveform </summary>
      MicrophoneWave,
      /// <summary> Microphone level </summary>
      MicrophoneLevel
    }

    /// <summary> Selectable input ranges </summary>
    public enum DaqInputRange
    {
      /// <summary> Range 1.25V </summary>
      Range1250Mv,
      /// <summary> Range 2.50V </summary>
      Range2500Mv,
      /// <summary> Range 5.00V </summary>
      Range5000Mv,
      /// <summary> Range 10.0V </summary>
      Range10000Mv
    }

    /// <summary> Selectable input ranges </summary>
    public enum DaqWaveType
    {
      /// <summary> Sine wave </summary>
      SineWave,
      /// <summary> Square wave </summary>
      SquareWave,
      /// <summary> Triangle wave </summary>
      TriangleWave,
      /// <summary> Ramp up </summary>
      UseRampUp,
      /// <summary> Ramp down </summary>
      UseRampDown,
      /// <summary> DC signal </summary>
      DcLevel
    }

    /// <summary> Available GPIO's </summary>
    public enum DaqOutput
    {
      /// <summary> Undefined </summary>
      Undefined,
      /// <summary> GPIO Nr. 1 </summary>
      GpioOne,
      /// <summary> GPIO Nr. 2 </summary>
      GpioTwo,
      /// <summary> GPIO Nr. 3 </summary>
      GpioThree,
      /// <summary> GPIO Nr. 4 </summary>
      GpioFour
    }

    /// <summary> DAQ board information strings </summary>
    public enum DaqInfoType
    {
      /// <summary> Driver version </summary>
      DriverVersion,
      /// <summary> USB version </summary>
      UsbVersion,
      /// <summary> Hardware version </summary>
      HardwareVersion,
      /// <summary> Variant information </summary>
      VariantInfo,
      /// <summary> Batch and serial number </summary>
      BatchAndSerial,
      /// <summary> calibration date </summary>
      CalibrationDate,
      /// <summary> Kernel driver version </summary>
      KernelDriverVersion
    }

    /// <summary> Data aquisition methods </summary>
    public enum DaqBlockMethod
    {
      /// <summary> Single data block </summary>
      UseSingle,
      /// <summary> Data window </summary>
      UseWindow,
      /// <summary> Data stream </summary>
      UseStream
    }

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqOpenUnit")]
    public static extern short OpenUnit(out short handle);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqCloseUnit")]
    public static extern short CloseUnit(short handle);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetUnitInfo")]
    public static extern short GetUnitInfo(short handle, StringBuilder daqstring, short stringLength, out short requiredSize, DaqInfoType daqinfo);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqRun")]
    public static extern short Run(short handle, uint noOfValues, DaqBlockMethod method);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqReady")]
    public static extern short Ready(short handle, out short isReady);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqStop")]
    public static extern short Stop(short handle);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetInterval")]
    public static extern short SetInterval(short handle, out ulong usForBlock, uint idealNoOfSamples, out DaqInput channels, short noOfChannels);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetTrigger")]
    public static extern short SetTrigger(short handle, ushort isEnabled, ushort autoTrigger, ushort autoMs, ushort channel, ushort direction, short threshold, ushort hysteresis, float delay);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetValues")]
    public static extern short GetValues(short handle, out short values, out ulong noOfValues, out ushort isOverflow, out ulong triggerIndex);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetTriggerTimeOffsetNs")]
    public static extern short GetTriggerTimeOffsetNs(short handle, out long time);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetSingle")]
    public static extern short GetSingle(short handle, DaqInput channel, out short value, out ushort isOverflow);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqOpenUnitAsync")]
    public static extern short OpenUnitAsync(out short status);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqOpenUnitProgress")]
    public static extern short OpenUnitProgress(out short handle, out short progress, out short isComplete);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetScalings")]
    public static extern short GetScalings(short handle, DaqInput channel, out short noOfScales, out short currentScale, out char names, short nameSize);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetScalings")]
    public static extern short SetScalings(short handle, DaqInput channel, short scalingNumber);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetSigGenBuiltIn")]
    public static extern short SetSigGenBuiltIn(short handle, long offsetVoltage, ulong peakToPeak, short frequency, DaqWaveType waveType);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetSigGenArbitrary")]
    public static extern short SetSigGenArbitrary(short handle, long offsetVoltage, ulong peakToPeak, out short arbitraryWaveform, short arbitraryWaveformSize, long updateRate);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqStopSigGen")]
    public static extern short StopSigGen(short handle);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetDO")]
    public static extern short SetDO(short handle, DaqOutput ioChannel, short value);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetPWM")]
    public static extern short SetPWM(short handle, DaqOutput ioChannel, ushort period, char cycle);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetInput")]
    public static extern short GetInput(short handle, DaqOutput ioChannel, short pullUp, out short value);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqStartPulseCount")]
    public static extern short StartPulseCount(short handle, DaqOutput ioChannel, short direction);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetPulseCount")]
    public static extern short GetPulseCount(short handle, DaqOutput ioChannel, out short count);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqEnableRGBLED")]
    public static extern short EnableRGBLED(short handle, short enabled);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqSetRGBLED")]
    public static extern short SetRGBLED(short handle, ushort red, ushort green, ushort blue);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqGetChannelInfo")]
    public static extern short GetChannelInfo(short handle, out float min, out float max, out short noOfPlaces, out short divider, DaqOutput channel);

    [DllImport(DriverDllName, EntryPoint = "UsbDrDaqPingUnit")]
    public static extern short PingUnit(short handle);
  }
}