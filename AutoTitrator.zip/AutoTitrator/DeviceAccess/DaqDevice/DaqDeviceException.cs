﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;

namespace AutoTitrator.DaqDevice
{
  public class DaqDeviceException : Exception
  {
    public DateTime DateTime { get; private set; }
    public DaqDeviceException(string aMessage, DateTime aDateTime = new DateTime()) : base(aMessage)
    {
      DateTime = aDateTime;
    }
  }
}