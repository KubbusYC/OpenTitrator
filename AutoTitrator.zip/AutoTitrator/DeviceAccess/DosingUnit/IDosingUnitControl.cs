﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

namespace AutoTitrator.DosingUnit
{
  public interface IDosingUnitControl
  {
    void InitializeDosingUnit();
    void SetZeroPosition();
    void SetStartPosition();
    void StartStirrer();
    void StopStirrer();
    double AddTitrant(double aVolumeMl);
  }
}
