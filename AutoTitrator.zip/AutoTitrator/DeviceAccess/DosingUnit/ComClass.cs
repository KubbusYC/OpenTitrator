﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Threading;

namespace AutoTitrator.DosingUnit
{
  public class ComClass
  {
    public ComClass()
    {
      Baud = 115200;                          //change BAUD datarate here
      Port = "COM3";                          //change COM-port here
      comEvent = new AutoResetEvent(false);
    }

    private SerialPort _serialPort;
    public int Increment { get; set; }
    public int Speed { get; set; }
    public string Port { get; private set; }
    public int Baud { get; private set; }
    private AutoResetEvent comEvent;


    public void InitializeSerialPort()
    {
      //initializing and opening new Serialport
      _serialPort = new SerialPort();
      _serialPort.PortName = Port;
      _serialPort.BaudRate = Baud;
      _serialPort.DataReceived += DataReceivedHandler;
      _serialPort.Open();
    }

    public void ZeroPosition()
    {
      //sets syringe on defined position (on arduino)
      _serialPort.Write("2");
      _serialPort.Write("1");
      _serialPort.Write("999");
      _serialPort.Write("\n");
      waitforreply();
    }

    private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
    {
      //send command for reply from arduino
      comEvent.Set();
    }

    public void Reset()
    {
      // sets syringe on 0 (0 is defined by the position of the syringe before first move command)
      _serialPort.Write("2");
      _serialPort.Write("0");
      _serialPort.Write("999");
      _serialPort.Write("\n");
      waitforreply();
    }

    public void IncrementExecution()
    {
      // for adding  defined amount of liquid, keep in mind to  only use 3 digits
      _serialPort.Write("2");
      _serialPort.Write("2");
      _serialPort.Write(Increment.ToString());
      _serialPort.Write("\n");
      waitforreply();
    }

    public void Startup()
    {
      // startup, keep in mind that the syringe has to be in desired position, this will be the reset position for all commands used in this session
      MagnetStirGo();
      Reset();
      MagnetStirStop();
      waitforreply();
    }

    public void ShutDown()
    {
      //shutdown, use everytime before turning off device
      MagnetStirStop();
      MagnetStirGo();
      ZeroPosition();
      MagnetStirStop();
      waitforreply();
    }

    public void MagnetStirGo()
    {
      //full speed
      _serialPort.Write("2");
      _serialPort.Write("6");
      _serialPort.Write("999");
      _serialPort.Write("\n");
      waitforreply();
    }

    public void MagnetStirStop()
    {
      //stop
      _serialPort.Write("2");
      _serialPort.Write("5");
      _serialPort.Write("999");
      _serialPort.Write("\n");
      waitforreply();
    }
    public void MagnetStirValue()
    {
      //defined speed, keep in mind that the speed reaches from 0-255
      if (Speed > 255 || Speed < 0)
      {
        throw new Exception("'Speed' out of range");
      }
      _serialPort.Write("2");
      _serialPort.Write("7");
      _serialPort.Write(Speed.ToString());
      _serialPort.Write("\n");
      waitforreply();
    }
    public void serialclose()
    {
      //close serialport programm is shut down to allow other programms to access it
      _serialPort.Close();
    }

    public void waitforreply()
    {
      //wait for answer from arduino
      if (!comEvent.WaitOne(60000))
      {
        //if there in no answer from the arduino within one minute, the error message "Timeout" is returned
        throw new Exception("Timeout");
      }
    }

  }
}