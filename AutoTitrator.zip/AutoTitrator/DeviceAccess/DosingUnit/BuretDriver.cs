﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;
using System.IO.Ports;
using System.Threading;

namespace AutoTitrator.DosingUnit
{
    public class BuretDriver
    {
        private readonly AutoResetEvent _orderDoneEvent;
        private SerialPort _serialPort;
        private readonly string _comPort;
        private readonly int _baudRate;

        public BuretDriver(string aComComPort, int aBaudRateRate)
        {
            _orderDoneEvent = new AutoResetEvent(false);
            _baudRate = aBaudRateRate; 
            _comPort = aComComPort; 
        }

        public void InitializeSerialPort()
        {
          _serialPort = new SerialPort
          {
            PortName = _comPort,
            BaudRate = _baudRate
          };

          _serialPort.DataReceived += DataReceivedHandler;
          _serialPort.Open();
        }

        public void ZeroPosition()
        {
            _serialPort.Write("2");
            _serialPort.Write("1");
            _serialPort.Write("999");
            _serialPort.Write("\n");
            WaitForReply();
        }

        public void Reset()
        {
            _serialPort.Write("2");
            _serialPort.Write("0");
            _serialPort.Write("999");
            _serialPort.Write("\n");
            WaitForReply();
        }

        public void AddStepsIncrement(int aNumberOfSteps)
        {
            _serialPort.Write("2");
            _serialPort.Write("2");
            _serialPort.Write(aNumberOfSteps.ToString("D3"));
            _serialPort.Write("\n");
            WaitForReply();
        }

        public void Startup()
        {
            Reset();
            WaitForReply();
        }

        public void ShutDown()
        {
            StopStirrer();
            ZeroPosition();
            WaitForReply();
        }

        public void StartStirrer()
        {
            _serialPort.Write("2");
            _serialPort.Write("6");
            _serialPort.Write("999");
            _serialPort.Write("\n");
            WaitForReply();
        }

        public void StopStirrer()
        {
            _serialPort.Write("2");
            _serialPort.Write("5");
            _serialPort.Write("999");
            _serialPort.Write("\n");
            WaitForReply();
        }

        public void SetStirrerSpeed(int aStirrerSpeed)
        {
          if (aStirrerSpeed > 255 || aStirrerSpeed < 0)
            {
                throw new Exception("'Speed' out of range");
            }

            _serialPort.Write("2");
            _serialPort.Write("7");
            _serialPort.Write(aStirrerSpeed.ToString());
            _serialPort.Write("\n");
            WaitForReply();
        }

        public void SerialClose()
        {
            _serialPort.Close();
        }

        public void WaitForReply()
        {
          if (!_orderDoneEvent.WaitOne(60000))
          {
              throw new Exception("Timeout");
          }
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
          _orderDoneEvent.Set();
        }
    }
}
