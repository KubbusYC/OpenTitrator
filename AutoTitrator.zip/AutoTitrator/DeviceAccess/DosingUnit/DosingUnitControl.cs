﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;

namespace AutoTitrator.DosingUnit
{
  public class DosingUnitControl : IDosingUnitControl
  {
    private const double MlPerStep = 0.001887;
    private const int StartOffset = 200;
    private const int MinNrOfSteps = 10;
    private const int MaxNrOfSteps = 265;
    private readonly BuretDriver _buret;


    public DosingUnitControl(string aComPort, int aBaudrate)
    {
      _buret = new BuretDriver(aComPort, aBaudrate);
    }

    public void InitializeDosingUnit()
    {
      _buret.InitializeSerialPort();
      _buret.SetStirrerSpeed(255);
    }

    public void SetZeroPosition()
    {
      _buret.Reset();
    }

    public void SetStartPosition()
    {
      _buret.AddStepsIncrement(StartOffset);
    }

    public void StartStirrer()
    {
      _buret.StartStirrer();
    }

    public void StopStirrer()
    {
      _buret.StopStirrer();
    }


    public double AddTitrant(double aVolumeMl)
    {
      var nrOfSteps = Convert.ToInt32(aVolumeMl / MlPerStep + 0.5);

      if (nrOfSteps < MinNrOfSteps)
      {
        nrOfSteps = MinNrOfSteps;
      }

      if (nrOfSteps > MaxNrOfSteps)
      {
        nrOfSteps = MaxNrOfSteps;
      }

      _buret.AddStepsIncrement(nrOfSteps);

      return nrOfSteps*MlPerStep;
    }
  }
}
