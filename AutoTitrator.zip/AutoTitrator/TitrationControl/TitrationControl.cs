﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;
using System.Threading;
using AutoTitrator.DaqDevice;
using AutoTitrator.Interfaces;
using AutoTitrator.DosingUnit;

namespace AutoTitrator
{
  public class TitrationControl : ITitrationControl
  {
    private const int MeasuringIntervalMs = 1000;
    private readonly IDosingUnitControl _dosingUnit;
    private readonly IDaqDevice _daqDevice;
    private readonly Simulation _simulation;
    private double _measuredValue;
    private double _addedVolume;
    private double _calculatedSlope;
    private double _initialSlope;
    private double _volumeIncrement;
    private double _previousIncrement;
    private double _previousPhValue;
    private bool _isInitialSlope;
    private bool _titrationAborted;
    private readonly TitratorSettings _titratorSettings;
    public Action<double, double, double> NewDataPoint { get; set; }
    public Action<double, double> NewMeasuredValue { get; set; }
    public Action TitrationComplete { get; set; }

    public TitrationControl(TitratorSettings aSettings)
    {
      _titratorSettings = aSettings;
      if (_titratorSettings.IsSimulation)
      {
        _simulation = new Simulation();
        _daqDevice = _simulation;
        _dosingUnit = _simulation;
      }
      else
      {
        _daqDevice = new DaqDeviceControl();
        _dosingUnit = new DosingUnitControl(_titratorSettings.BuretComPort, _titratorSettings.BuretBaudRate);
      }
    }

    public void StartTitration()
    {
      if (_titratorSettings.IsSimulation)
      {
        _simulation.ResetTitration();
      }

      var titrationRunner = new Thread(RunTitration);
      _titrationAborted = false;
      _previousPhValue = 0;
      _previousIncrement = 0;
      _volumeIncrement = _titratorSettings.MaxVolumeIncrement;
      _addedVolume = 0;
      _isInitialSlope = true;
      _dosingUnit.StartStirrer();
      titrationRunner.Start();
    }

    public void StopTitration()
    {
      _titrationAborted = true;
    }

    public void StartStirrer()
    {
      _dosingUnit.StartStirrer();
    }

    public void StopStirrer()
    {
      _dosingUnit.StopStirrer();
    }

    public void InitializeHardware()
    {
      _dosingUnit.InitializeDosingUnit();
      _dosingUnit.StopStirrer();
      _daqDevice.InitializeDaqDevice();
    }

    public void SetBuretZeroPosition()
    {
      _dosingUnit.SetZeroPosition();
    }

    public void SetBuretStartPosition()
    {
      _dosingUnit.SetStartPosition();
    }

    private void RunTitration()
    {
      bool titrationFinished = false;
      MeasureValue(_titratorSettings.StabilizingTimeSec);
      StoreMeasuredValues();
      while (!titrationFinished && !_titrationAborted) 
      { 
        titrationFinished = IsTitrationFinished();
        if (!titrationFinished && !_titrationAborted)
        {
          AddTitrant();
          MeasureValue(_titratorSettings.StabilizingTimeSec);
          CalculateIncrement();
          StoreMeasuredValues();
        }
      }

      _dosingUnit.StopStirrer();

      if (TitrationComplete != null)
      {
        TitrationComplete();
      }
    }

    private void AddTitrant()
    {
      _volumeIncrement = _dosingUnit.AddTitrant(_volumeIncrement);
       _addedVolume += _volumeIncrement;
    }

    private void MeasureValue(int aStabilizingTime)
    {
      while (aStabilizingTime > 0)
      {
        _measuredValue = _daqDevice.ReadPhValue();
        NewMeasuredValue(_addedVolume, _measuredValue);
        Thread.Sleep(MeasuringIntervalMs);
        aStabilizingTime--;
      }
    }

    private void StoreMeasuredValues()
    {
      _previousIncrement = _volumeIncrement;
      _previousPhValue = _measuredValue;

      if (NewDataPoint != null)
      {
        NewDataPoint(_addedVolume, _measuredValue, _calculatedSlope);
      }
    }
    private void CalculateIncrement()
    {
      _calculatedSlope = Math.Abs((_measuredValue - _previousPhValue) / _previousIncrement);

      if (_calculatedSlope > 1E-10)
      {
        if (_isInitialSlope)
        {
          _initialSlope = _calculatedSlope;
          _isInitialSlope = false;
        }
        else
        {
          var slopeFactor = _calculatedSlope / _initialSlope;
          _volumeIncrement = Math.Round(100 * (_titratorSettings.MaxVolumeIncrement / slopeFactor)) / 100;

          if (_volumeIncrement < _titratorSettings.MinVolumeIncrement)
          {
            _volumeIncrement = _titratorSettings.MinVolumeIncrement;
          }

          if (_volumeIncrement > _titratorSettings.MaxVolumeIncrement)
          {
            _volumeIncrement = _titratorSettings.MaxVolumeIncrement;
          }
        }
      }
    }

    private bool IsTitrationFinished()
    {
      return _addedVolume >= _titratorSettings.MaxTitrantVolume;
    }
  }
}
