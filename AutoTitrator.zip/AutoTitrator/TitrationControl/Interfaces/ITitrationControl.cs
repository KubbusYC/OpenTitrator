﻿//-------------------------------------------------------------------------------------------------
// Titrator Project (Matura-Arbeit Kantonschule Baden)
// Copyright (c) 2017, Samuel Räber, Luca Sichi, ...
//-------------------------------------------------------------------------------------------------

using System;

namespace AutoTitrator.Interfaces
{
  public interface ITitrationControl
  {
    Action<double, double, double> NewDataPoint { get; set; }
    Action<double, double> NewMeasuredValue { get; set; }
    Action TitrationComplete { get; set; }
    void InitializeHardware();
    void SetBuretZeroPosition();
    void SetBuretStartPosition();
    void StartTitration();
    void StopTitration();
    void StartStirrer();
    void StopStirrer();
  }
}
