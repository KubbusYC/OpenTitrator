﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoTitrator.DaqDevice;
using AutoTitrator.DosingUnit;

namespace AutoTitrator
{
  class Simulation : IDaqDevice, IDosingUnitControl
  {
    private const double pKw = 14.0;
    private const double hTotal = 0.0005;
    private const double vStart = 0.02;
    private const double titrantConc = 0.1;
    private double _addedVolume;


    public void InitializeDosingUnit()
    {
      // Not needed for simulation.
    }

    public void SetZeroPosition()
    {
      // Not needed for simulation.
    }

    public void SetStartPosition()
    {
      // Not needed for simulation.
    }

    public void StartStirrer()
    {
      // Not needed for simulation.
    }

    public void StopStirrer()
    {
      // Not needed for simulation.
    }

    public double AddTitrant(double aVolumeMl)
    {
      _addedVolume += 0.001 * aVolumeMl;
      return aVolumeMl;
    }

    public void InitializeDaqDevice()
    {
      // Not needed for simulation.
    }

    public void FinalizeDaqDevice()
    {
      // Not needed for simulation.
    }

    public double GetTemperature()
    {
      // Not needed for simulation.
      return 0.0;
    }

    public double ReadPhValue()
    {
      double hConc = (hTotal - _addedVolume * titrantConc) / (vStart + _addedVolume);
      double phValue = 7.0;

      if (hConc > 1E-7)
      {
        phValue = -Math.Log10(hConc);
      }
      else if (hConc < 0)
      {
        phValue = pKw + Math.Log10(-hConc);
      }

      return phValue;
    }

    public void ResetTitration()
    {
      _addedVolume = 0;
    }
  }
}
