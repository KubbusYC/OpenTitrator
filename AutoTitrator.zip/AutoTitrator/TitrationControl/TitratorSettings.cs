﻿namespace AutoTitrator
{
  public class TitratorSettings
  {
    public double SampleVolume { get; set; }
    public double MaxTitrantVolume { get; set; }
    public double MinVolumeIncrement { get; set; }
    public double MaxVolumeIncrement { get; set; }
    public int StabilizingTimeSec { get; set; }
    public string BuretComPort { get; set; }
    public int BuretBaudRate { get; set; }
    public bool IsSimulation { get; set; }
  }
}
