﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.WindowsForms;

namespace OxyPlotTest
{
  public partial class Form1 : Form
  {
    private OxyPlot.WindowsForms.PlotView _plot;

    public Form1()
    {
      InitializeComponent();
      var myModel = new PlotModel { Title = "Example 1" };
      myModel.Series.Add(new FunctionSeries(Math.Cos, 0, 10, 0.1, "cos(x)"));
      _plot = new PlotView {Model = myModel};
      SuspendLayout();
      _plot.Dock = System.Windows.Forms.DockStyle.Fill;
      _plot.Location = new System.Drawing.Point(0, 0);
      _plot.Name = "plot1";
      _plot.PanCursor = System.Windows.Forms.Cursors.Hand;
      _plot.Size = new System.Drawing.Size(484, 312);
      _plot.TabIndex = 0;
      _plot.Text = "plot";
      _plot.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
      _plot.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
      _plot.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
      Controls.Add(_plot);
      ResumeLayout(false);
    }
  }
}
