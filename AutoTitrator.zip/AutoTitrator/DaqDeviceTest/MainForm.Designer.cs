﻿namespace AutoTitrator
{
  partial class MainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.BtnInitDaq = new System.Windows.Forms.Button();
      this.BtnSetRgbLed = new System.Windows.Forms.Button();
      this.TbxTemperature = new System.Windows.Forms.TextBox();
      this.BtnGetTemperature = new System.Windows.Forms.Button();
      this.TbxExtOne = new System.Windows.Forms.TextBox();
      this.BtnExtOne = new System.Windows.Forms.Button();
      this.BtnReadPh = new System.Windows.Forms.Button();
      this.TbxPhValue = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // BtnInitDaq
      // 
      this.BtnInitDaq.Location = new System.Drawing.Point(179, 216);
      this.BtnInitDaq.Name = "BtnInitDaq";
      this.BtnInitDaq.Size = new System.Drawing.Size(84, 23);
      this.BtnInitDaq.TabIndex = 0;
      this.BtnInitDaq.Text = "Init DAQ";
      this.BtnInitDaq.UseVisualStyleBackColor = true;
      this.BtnInitDaq.Click += new System.EventHandler(this.BtnInitDaq_Click);
      // 
      // BtnSetRgbLed
      // 
      this.BtnSetRgbLed.Location = new System.Drawing.Point(179, 177);
      this.BtnSetRgbLed.Name = "BtnSetRgbLed";
      this.BtnSetRgbLed.Size = new System.Drawing.Size(84, 23);
      this.BtnSetRgbLed.TabIndex = 1;
      this.BtnSetRgbLed.Text = "Set RGB LED";
      this.BtnSetRgbLed.UseVisualStyleBackColor = true;
      this.BtnSetRgbLed.Click += new System.EventHandler(this.BtnSetRgbLed_Click);
      // 
      // TbxTemperature
      // 
      this.TbxTemperature.Location = new System.Drawing.Point(13, 142);
      this.TbxTemperature.Name = "TbxTemperature";
      this.TbxTemperature.ReadOnly = true;
      this.TbxTemperature.Size = new System.Drawing.Size(100, 20);
      this.TbxTemperature.TabIndex = 2;
      // 
      // BtnGetTemperature
      // 
      this.BtnGetTemperature.Location = new System.Drawing.Point(179, 142);
      this.BtnGetTemperature.Name = "BtnGetTemperature";
      this.BtnGetTemperature.Size = new System.Drawing.Size(84, 23);
      this.BtnGetTemperature.TabIndex = 3;
      this.BtnGetTemperature.Text = "Get Temp";
      this.BtnGetTemperature.UseVisualStyleBackColor = true;
      this.BtnGetTemperature.Click += new System.EventHandler(this.BtnGetTemperature_Click);
      // 
      // TbxExtOne
      // 
      this.TbxExtOne.Location = new System.Drawing.Point(13, 106);
      this.TbxExtOne.Name = "TbxExtOne";
      this.TbxExtOne.ReadOnly = true;
      this.TbxExtOne.Size = new System.Drawing.Size(100, 20);
      this.TbxExtOne.TabIndex = 4;
      // 
      // BtnExtOne
      // 
      this.BtnExtOne.Location = new System.Drawing.Point(179, 102);
      this.BtnExtOne.Name = "BtnExtOne";
      this.BtnExtOne.Size = new System.Drawing.Size(84, 23);
      this.BtnExtOne.TabIndex = 5;
      this.BtnExtOne.Text = "Sensor 1";
      this.BtnExtOne.UseVisualStyleBackColor = true;
      this.BtnExtOne.Click += new System.EventHandler(this.BtnExtOne_Click);
      // 
      // BtnReadPh
      // 
      this.BtnReadPh.Location = new System.Drawing.Point(179, 65);
      this.BtnReadPh.Name = "BtnReadPh";
      this.BtnReadPh.Size = new System.Drawing.Size(84, 23);
      this.BtnReadPh.TabIndex = 6;
      this.BtnReadPh.Text = "pH Value";
      this.BtnReadPh.UseVisualStyleBackColor = true;
      this.BtnReadPh.Click += new System.EventHandler(this.BtnReadPh_Click);
      // 
      // TbxPhValue
      // 
      this.TbxPhValue.Location = new System.Drawing.Point(13, 67);
      this.TbxPhValue.Name = "TbxPhValue";
      this.TbxPhValue.Size = new System.Drawing.Size(100, 20);
      this.TbxPhValue.TabIndex = 7;
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(284, 261);
      this.Controls.Add(this.TbxPhValue);
      this.Controls.Add(this.BtnReadPh);
      this.Controls.Add(this.BtnExtOne);
      this.Controls.Add(this.TbxExtOne);
      this.Controls.Add(this.BtnGetTemperature);
      this.Controls.Add(this.TbxTemperature);
      this.Controls.Add(this.BtnSetRgbLed);
      this.Controls.Add(this.BtnInitDaq);
      this.MinimizeBox = false;
      this.Name = "MainForm";
      this.Text = "DAQ Device";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button BtnInitDaq;
    private System.Windows.Forms.Button BtnSetRgbLed;
    private System.Windows.Forms.TextBox TbxTemperature;
    private System.Windows.Forms.Button BtnGetTemperature;
    private System.Windows.Forms.TextBox TbxExtOne;
    private System.Windows.Forms.Button BtnExtOne;
    private System.Windows.Forms.Button BtnReadPh;
    private System.Windows.Forms.TextBox TbxPhValue;
  }
}

