﻿using System;
using System.Windows.Forms;
using AutoTitrator.DaqDevice;

namespace AutoTitrator
{
  public partial class MainForm : Form
  {
    private DaqDeviceControl _deviceControl;

    public MainForm()
    {
      InitializeComponent();
      _deviceControl = new DaqDeviceControl();
    }

    private void BtnInitDaq_Click(object sender, EventArgs e)
    {
      try
      {
        _deviceControl.InitializeDaqDevice();
        MessageBox.Show(_deviceControl.CalibrationDate);
      }
      catch (DaqDeviceException ex)
      {
        MessageBox.Show(ex.Message + @": " + ex.DateTime);
      }
    }

    private void BtnSetRgbLed_Click(object sender, EventArgs e)
    {
      _deviceControl.SetRgbLedColor(0, 0, 255);
    }

    private void BtnGetTemperature_Click(object sender, EventArgs e)
    {
      var temperature = _deviceControl.GetTemperature();
      TbxTemperature.Text = temperature.ToString("F1");
    }

    private void BtnExtOne_Click(object sender, EventArgs e)
    {
      var sensorValue = _deviceControl.GetExternalSensorOne();
      TbxExtOne.Text = sensorValue.ToString("F1");
    }

    private void BtnReadPh_Click(object sender, EventArgs e)
    {
      var sensorValue = _deviceControl.ReadPhValue();
      TbxPhValue.Text = sensorValue.ToString("F2");
    }
  }
}
